# Project Agent Factory Build Report

## Result

- Package: `project-agent-factory`
- Ready for Use: `YES`
- Consistency status: `PASS`
- Structural validation: `0 errors, 0 warnings`
- Master entry prompt: `prompts/00_project_agent_factory.md`

## Delivered System

- Nine ordered prompts covering analysis, specification, generation, review, and assembly.
- A detailed project-description input template.
- Six design and maintenance guides.
- Four quality checklists.
- Agent, rule, skill, and handoff starter templates.
- Repository, framework, catalog, rule-map, generation, and consistency output templates.
- JSON schemas for framework companion data and generated ownership manifests.
- Reusable static validators for the factory and generated ecosystems.
- A complete source-derived thermal/power/telemetry `.cursor` example.

## Source Repairs

- Reconstructed the uploaded `feature-intake/SKILL.md`, which ended mid-workflow in an unclosed code block.
- Closed the uploaded planner's unfinished plan-format code block and added stop/handoff behavior.
- Corrected `workflow_triange` to `workflow_triage`.
- Removed an outer Markdown wrapper from the workflow-triage agent.
- Normalized malformed apostrophes.
- Removed example-specific hardcoded model identifiers for portability.

## Design Decisions

- Repository evidence is collected before role generation.
- Role topology is specified before files are written.
- Agents are justified by distinct decisions, not technology labels.
- Persistent rules, specialist methods, workflow orchestration, and handoff shapes are separated.
- Existing `.cursor` content is ownership-aware and never silently overwritten.
- Description-only mode remains provisional and marks unverified repository facts.
- Revision loops are bounded and negative gates stop planning.
- Validation includes scenario simulation and manifest-backed ownership checks.

## Validation Coverage

The included validator checks prompt continuity, required factory files, JSON syntax, generated ecosystem directories, frontmatter, filename/name alignment, rule scope metadata, skill size, Markdown fences, referenced templates, obsolete identifiers, agent mentions, canonical gate vocabulary, manifest fields, owned-file existence, and content hashes.

## Invocation

Attach `prompts/00_project_agent_factory.md` and a completed `inputs/project-description.template.md` to Cursor, then instruct it to execute the complete factory against the target repository.
